# DSE 數學操卷神器

線上版：https://aaronmath.github.io/dse-math-tracker/

**呢個倉庫根目錄就係完整網站。** 冇 `artifacts` 資料夾，亦冇多一層 `dse-math-tracker/` 子目錄（GitHub Pages 必須把 `index.html` 放在根目錄）。

## 下載本地完整包

檔案名：**[dse-math-tracker.zip](./dse-math-tracker.zip)**

- 檔案列表：[dse-math-tracker.zip](./dse-math-tracker.zip)
- 正式下載（較穩）：[Releases · dse-math-tracker.zip](https://github.com/aaronmath/dse-math-tracker/releases/latest/download/dse-math-tracker.zip)

1. 下載 ZIP，解壓會得到資料夾 `dse-math-tracker`
2. 用瀏覽器打開入面嘅 `index.html`（Chrome / Safari / Edge 都得）
3. 唔使安裝、唔使伺服器。資料存在本機瀏覽器。可用「過檔」出示／掃入 QR（狀態、分數、錯因），或匯出／匯入 JSON（匯出只含當前學生；匯入可一次多個檔，含筆記）

年份 2012–2026。分頁：進度／能力／MC／成績／全港平均／Cut-off／計時。

- 能力雷達試卷次序：必修卷一 → 必修卷二 → M1 → M2（M1/M2 暫未有課題分類）
- 卷一雷達用**主課題 + 分數加權**；摘錄可篩「一般／唔識」，難度三檔預設全開
- 進度卷一／卷二都可按課題反查；選呢年／選部再撳可取消
- 過檔 QR：狀態＋分數＋錯因；掃入後可合併／覆蓋／新增。JSON 仍作完整備份（含筆記）
- 全港平均卷一單年課題名預設隱藏；「卷一課題表現」短表可隨時打開

## 放到 GitHub Pages

1. 開新 repository（建議 **Public**）。
2. 把本資料夾的檔案放在 repo **根目錄**（要見到 `index.html`，不要多一層資料夾）。唔使上傳 ZIP。
3. Settings → Pages → Build and deployment → Source: **Deploy from a branch** → Branch: `main` / `root` → Save。
4. 一兩分鐘後網址類似：`https://你的帳號.github.io/倉庫名/`

有 link 的人就可以開。GitHub Pages **沒有「只有連結先睇到」的隱藏模式**：Public 網站任何人有網址都能開，搜尋引擎也可能收錄。Private repo 可以藏原始碼，但 Pages 網站本身多數仍然公開（私人 Pages 要付費方案）。學生資料在各自瀏覽器，互不相見。

Powered by Chan Yiu Hei
